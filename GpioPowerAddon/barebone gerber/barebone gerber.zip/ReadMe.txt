FILES:

GpioPowerAddon.gtl		top metal layer
GpioPowerAddon.gbl		bottom metal layer
GpioPowerAddon.gd1		drill drawing w/ pcb border
GpioPowerAddon.drl		NC Drill file (all holes, with tool header)

board x-dimension 3.3 in.
board y-dimension 1 in.

-----------------------------
CONTACT INFO:

Chuck Yang
ty244@cornell.edu
(402) 500-0617 